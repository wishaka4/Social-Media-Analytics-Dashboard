from django.apps import AppConfig


class RedditConfig(AppConfig):
    name = 'reddit'
