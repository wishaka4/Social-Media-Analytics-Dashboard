from django.apps import AppConfig


class TwitterApiConfig(AppConfig):
    name = 'twitter_api'
